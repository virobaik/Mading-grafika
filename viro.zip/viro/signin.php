<?php
session_start();

$koneksi = mysqli_connect('localhost', 'root', '', 'mading_grafika');


$username = $_POST['username'];
$password = $_POST['password'];


$query = mysqli_query($koneksi, "select * from users where username='$username' and password='$password'");
var_dump($query);
$cek = mysqli_num_rows($query);

if ($cek > 0) {
    $_SESSION['username'] = $username;
    $_SESSION['status'] = "login";
    header("location:index.php");
} else {
    echo 'username / password salah';
}
