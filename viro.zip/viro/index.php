<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Home | Mading Grafika</title>

    <style>
        /* http://meyerweb.com/eric/tools/css/reset/ 
   v2.0 | 20110126
   License: none (public domain)
*/

        html,
        body,
        div,
        span,
        applet,
        object,
        iframe,
        blockquote,
        pre,
        a,
        abbr,
        acronym,
        address,
        big,
        cite,
        code,
        del,
        dfn,
        em,
        img,
        ins,
        kbd,
        q,
        s,
        samp,
        small,
        strike,
        strong,
        sub,
        sup,
        tt,
        var,
        b,
        u,
        i,
        center,
        dl,
        dt,
        dd,
        ol,
        ul,
        li,
        fieldset,
        form,
        label,
        legend,
        table,
        caption,
        tbody,
        tfoot,
        thead,
        tr,
        th,
        td,
        article,
        aside,
        canvas,
        details,
        embed,
        figure,
        figcaption,
        footer,
        header,
        hgroup,
        menu,
        nav,
        output,
        ruby,
        section,
        summary,
        time,
        mark,
        audio,
        video {
            margin: 0;
            padding: 0;
            border: 0;
            font-size: 100%;
            font: inherit;
            vertical-align: baseline;
        }

        /* HTML5 display-role reset for older browsers */
        article,
        aside,
        details,
        figcaption,
        figure,
        footer,
        header,
        hgroup,
        menu,
        nav,
        section {
            display: block;
        }

        body {
            line-height: 1;
        }

        ol,
        ul {
            list-style: none;
        }

        blockquote,
        q {
            quotes: none;
        }

        blockquote:before,
        blockquote:after,
        q:before,
        q:after {
            content: '';
            content: none;
        }

        table {
            border-collapse: collapse;
            border-spacing: 0;
        }

        .footer {

            width: 100%;
            background-color: black;
            color: white;
            text-align: center;
        }
    </style>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-color: #FFFFFF;">
        <div class="container">
            <a class="navbar-brand" href="#">Mading Grafika</a>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">Profile</a>
                    </li>

                    <?php
                    session_start();
                    if (isset($_SESSION['status'])) :
                    ?>
                        <?php if ($_SESSION['status'] != 'login') : ?>
                            <li class="nav-item">
                                <button type="button" class="btn btn-outline-primary btn-sm"><a class="nav-link" href="login.php">Login</a></button>
                            </li>
                        <?php elseif ($_SESSION['status'] == 'login') :
                        ?>
                            <li class="nav-item">
                                <button type="button" class="btn btn-outline-primary btn-sm"><a class="nav-link" href="logout.php">Logout</a></button>
                            </li>
                        <?php endif; ?>
                    <?php else : ?>

                        <li class="nav-item">
                            <button type="button" class="btn btn-outline-primary btn-sm"><a class="nav-link" href="login.php">Login</a></button>
                        </li>
                    <?php endif; ?>

                </ul>
                <span class="navbar-text">
                    <img src="images/logo.png" alt="logo" height="40%" width="40%">
                </span>
            </div>
        </div>
    </nav>

    <div id="carouselExampleControlsNoTouching" class="carousel slide" data-bs-touch="false" data-bs-interval="false">
        <div class="carousel-inner" style="height: 600px;">
            <div class="carousel-item active">
                <img src="images/slider1.JPG" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="images/slider2.JPG" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="images/slider3.JPG" class="d-block w-100" alt="...">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    </div>

    <div class="container">
        <div class=" d-flex justify-content-center mt-5">
            <img src="images/logo.png" alt="">
        </div>
        <h1 class="mx-auto mt-3" style="text-align: center;">INFORMASI WISUDA</h1>
        <div class="row mx-auto mt-3">
            <div class="col me-3 p-5" style="text-align: center;background-color: #e6f7ff; border-radius: 10px; padding: 17px;">
                <h2>Tempat Diselenggarakan</h2>
                <h4>Labana SMKN 4 Malang</h4>
            </div>
            <div class="col ms-3 p-5" style="text-align: center;background-color: #e6f7ff; border-radius: 10px; padding: 17px;">
                <h2>Waktu Diselenggarakan</h2>
                <h4>Kamis, 23 Juni 2022</h4>
            </div>
        </div>
    </div>

    <div class="container p-5 my-5" style="display: flex;text-align: center;background-color: #181A18; border-radius: 10px; padding: 17px;color: #efefef;align-items: center;justify-content: center; ">
        <img src="images/slider1.JPG" alt="" height="50%" width="50%">
        <h5 class="ms-5" style="text-align: center;">SMK Negeri 4 Malang adalah Sekolah Menengah Kejuruan Negeri yang ada di Malang yang beralamat di Jl. Tanimbar 22 Malang
            Sekolah ini mempunyai 9 jurusan, yaitu Produksi Grafika, Persiapan Grafika, Multimedia, Rekayasa Perangkat Lunak, Animasi, TKJ, Mekatronika, Logistik dan Akomodasi Perhotelan
            Jumlah siswa di sekolah ini sekitar 3300 siswa dengan rincian setiap tingkatan kelas terdiri dari 1100 siswa</h5>
    </div>

    <div class="footer p-3">
        <p>Dev by : Viro Arnesto si baik hati </p>
    </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
</body>

</html>