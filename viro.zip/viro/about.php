<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Profile | Mading Grafika</title>

    <style>
        /* http://meyerweb.com/eric/tools/css/reset/ 
   v2.0 | 20110126
   License: none (public domain)
*/

        html,
        body,
        div,
        span,
        applet,
        object,
        iframe,
        blockquote,
        pre,
        a,
        abbr,
        acronym,
        address,
        big,
        cite,
        code,
        del,
        dfn,
        em,
        img,
        ins,
        kbd,
        q,
        s,
        samp,
        small,
        strike,
        strong,
        sub,
        sup,
        tt,
        var,
        b,
        u,
        i,
        center,
        dl,
        dt,
        dd,
        ol,
        ul,
        li,
        fieldset,
        form,
        label,
        legend,
        caption,
        article,
        aside,
        canvas,
        details,
        embed,
        figure,
        figcaption,
        footer,
        header,
        hgroup,
        menu,
        nav,
        output,
        ruby,
        section,
        summary,
        time,
        mark,
        audio,
        video {
            margin: 0;
            padding: 0;
            border: 0;
            font-size: 100%;
            font: inherit;
            vertical-align: baseline;
        }

        /* HTML5 display-role reset for older browsers */
        article,
        aside,
        details,
        figcaption,
        figure,
        footer,
        header,
        hgroup,
        menu,
        nav,
        section {
            display: block;
        }

        body {
            line-height: 1;
        }

        ol,
        ul {
            list-style: none;
        }

        blockquote,
        q {
            quotes: none;
        }

        blockquote:before,
        blockquote:after,
        q:before,
        q:after {
            content: '';
            content: none;
        }

        table {
            border-collapse: collapse;
            border-spacing: 0;
            margin: 0 auto;
        }

        .footer {

            width: 100%;
            background-color: black;
            color: white;
            text-align: center;
        }

        .styled-table {
            border-collapse: collapse;
            margin: 25px auto;
            font-size: 0.9em;
            font-family: sans-serif;
            min-width: 400px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }

        .styled-table thead tr {
            background-color: #404040;
            color: #efefe2;
            text-align: center;
        }

        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
        }

        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
            background-color: #f3f3f3;
            font-weight: bold;
            color: #181A18;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #181A18;
        }
    </style>

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light" style="background-color: #FFFFFF;">
        <div class="container">
            <a class="navbar-brand" href="#">Mading Grafika</a>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Profile</a>
                    </li>
                    <li class="nav-item">
                        <button type="button" class="btn btn-outline-primary btn-sm"><a class="nav-link" href="login.php">Login</a></button>
                    </li>
                </ul>
                <span class="navbar-text">
                    <img src="images/logo.png" alt="logo" height="40%" width="40%">
                </span>
            </div>
        </div>
    </nav>


    <div class="container" style="text-align: center;">
        <div class=" d-flex justify-content-center mt-5">
            <img src="images/logo.png" alt="">
        </div>
        <h1 class="mx-auto mt-3" style="text-align: center;">Profile Sekolah</h1>
        <h5 style="background-color: #e6f7ff; border-radius: 10px; padding: 17px;">Pada tanggal 26-05-1979 sesuai dengan Surat Keputusan Menteri Pendidikan Nasional Nomor 090/0/1979, maka menjadi dasar bagi berdirinya sebuah Sekolah Menengah Kejuruan Negeri 4 Malang yang berlokasi di Jalan Jl. Tanimbar 22, Kasin, Klojen, Kota Malang, Provinsi Jawa Timur – Indonesia, dengan NPSN 20533816. SMK Negeri 4 Malang dibangun di atas tanah seluas 12.410 m2 yang berdiri bangunan-bangunan diatasnya serta melakukan pengembangan setiap tahunnya untuk penambahan bangunan, pengembangan pembelajaran, dan sistem manajemen</h5>
        <h5 style="background-color: #e6f7ff; border-radius: 10px; padding: 17px;">SMKN 4 Malang (Grafika) mempunyai 9 jurusan yaitu, Persiapan Grafika,Produksi Grafika,Multimedia, Rekayasa Perangkat lunak (RPL), Teknik Komputer dan Jaringan (TKJ),Animasi, Mekatronika, Logistik dan Perhotelan. Jumlah siswa di SMKN 4 Malang sekitar 3300 siswa dengan rincian setiap angkatan kelas terdiri dari kurang lebih 1100 siswa.</h5>


        <h1 class="mx-auto my-3" style="text-align: center;">Bidang Keahlian</h1>


        <div class="row">
            <div class="col me-3" style="text-align:center;background-color: #e8fbe1; border-radius: 10px; padding: 17px;color: #efefef;align-items: center;justify-content: center;">
                <h4 style="color: black;">Bidang Studi Keahlian Teknologi dan Rekayasa</h4>
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>Program Studi Keahlian</th>
                            <th>Kompetensi Keahlian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td scope="row" rowspan="2">Teknik Grafika</td>
                            <td>Desain Grafika</td>
                        </tr>
                        <tr>
                            <td scope="row">Produksi Grafika</td>
                        </tr>
                        <tr>
                            <td scope="row">Teknik Elektronika</td>
                            <td colspan="2">Teknik Mekatronika</td>
                        </tr>
                        <tr>
                            <td scope="row">Teknik Industri</td>
                            <td>Logistik</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="col ms-3" style="text-align:center;background-color: #e8fbe1; border-radius: 10px; padding: 17px;color: #efefef;align-items: center;justify-content: center;">
                <h4 style="color: black;">Bidang Studi Keahlian Teknologi Informasi dan Komunikasi</h4>
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>Program Studi Keahlian</th>
                            <th>Kompetensi Keahlian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td scope="row" rowspan="4">Teknik Komputer dan Informatika</td>
                        </tr>
                        <tr>
                            <td scope="row">Rekayasa Perangkat Lunak</td>
                        </tr>
                        <tr>
                            <td scope="row">Teknik Komputer Dan Jaringan</td>
                        </tr>
                        <tr>
                            <td scope="row">Multimedia</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>



        <div class="row my-4 mb-5">
            <div class="col me-3" style="text-align:center;background-color: #e8fbe1; border-radius: 10px; padding: 17px;color: #efefef;align-items: center;justify-content: center;">
                <h4 style="color: black;">Bidang Studi Pariwisata</h4>
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>Program Studi Keahlian</th>
                            <th>Kompetensi Keahlian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td scope="row">Perhotelan dan Jasa Pariwisata</td>
                            <td>Perhotelan</td>
                        </tr>

                    </tbody>
                </table>
            </div>
            <div class="col ms-3" style="text-align:center;background-color: #e8fbe1; border-radius: 10px; padding: 17px;color: #efefef;align-items: center;justify-content: center;">
                <h4 style="color: black;">Seni dan Industri Kreatif</h4>
                <table class="styled-table">
                    <thead>
                        <tr>
                            <th>Program Studi Keahlian</th>
                            <th>Kompetensi Keahlian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td scope="row">Seni Rupa</td>
                            <td>Animasi</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </div>


    <div class="footer p-3">
        <p>Dev by : Viro Arnesto si baik hati </p>
    </div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
</body>

</html>